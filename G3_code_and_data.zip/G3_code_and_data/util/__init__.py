#submodules declaration
__all__ = ["catalogue","cleansing", "general", "plotting","storage"]
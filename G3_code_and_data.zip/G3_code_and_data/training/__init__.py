# submodules declaration
__all__ = ["analysis","plotting","training_lr","training_rf","training_svm"]